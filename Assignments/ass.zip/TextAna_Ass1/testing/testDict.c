#include <stdio.h>

#include "Dict.h"

int
main(void)
{
	white_box();


	return 0;
}
